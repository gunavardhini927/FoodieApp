package com.example.foodieapp

class UserProfile {
    var name:String?=null;
    var phoneNumber:String?=null;
    var email:String?=null;
    var pincode:String?=null;
    var address:String?=null;
}